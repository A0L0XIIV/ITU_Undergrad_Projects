#include <linux/syscalls.h>
#include <linux/kernel.h>


asmlinkage long set_myFlag(pid_t pid, int flag)
{
	printk("%d is calling set_myFlag (sys_getuid() = %d)\n", pid, sys_getuid());
	if(sys_getuid() != 0) return -EACCES;
	(find_task_by_vpid(pid))->myFlag = flag;
	return 0;
}


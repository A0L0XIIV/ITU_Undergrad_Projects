#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/resource.h>
#include <sys/errno.h>

#define MYCALL 355

int main(int argc, char *argv[])
{
	if ((argv[1]) == NULL)return 0;
	int prio = (int) strtod(argv[1], NULL);
	if (!prio || prio>19 || prio < -20)
	{
		puts("please run the function with a value between -20 and 19");
		return 1;
	}
	printf("Hello, I am %d\n", getpid());
	pid_t y = 0;
	setpriority(PRIO_PROCESS, 0, prio);
	y =fork();
	if (y != 0 ) y = fork();
	if (y==0) printf("Hello I am number %d\n My pid is %d\n", y, getpid());
	if(!getuid()) puts("I am running under a root command");
	else puts("I am not running under a root command");
	if (y != 0 )
	{
		printf("This is my getuid: %d\n", getuid());
		printf("This is my nice value: %d\n", getpriority(PRIO_PROCESS, 0));
	}
	syscall(MYCALL, getpid(), 1);
	puts("cool");
	return 0;
}

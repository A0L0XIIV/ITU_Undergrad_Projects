#define AD_UZUNLUK 30
#define TELNO_UZUNLUK 15
struct list_node{
    char telno[TELNO_UZUNLUK];
    list_node *next;
};

struct Tel_dugum{
    char ad[AD_UZUNLUK];
    Tel_dugum *sol;
    Tel_dugum *sag;
    list_node *number;

};

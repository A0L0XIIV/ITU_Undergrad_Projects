#include <iostream>
#include <stdlib.h>
#include <iomanip>

#include <ctype.h>
#include <cstring>

#include "agac.h"

using namespace std;

typedef Tel_dugum Tel_Kayit;
typedef Agac Veriyapisi;

Veriyapisi defter;


void menu_yazdir();
bool islem_yap(char);
void kayit_ara();
void kayit_ekle();
void kayit_sil();
void kayit_guncelle();
void temizle();
void numara_ekle();

int main(){
    defter.olustur();
    bool bitir = false;
    char secim;
    while (!bitir) {
        menu_yazdir();
        cin >> secim;
        bitir = islem_yap(secim);
    }
    defter.kapat();
}

void menu_yazdir(){
    cout << endl << endl;
    cout << "Telefon Defteri Uygulamasi" << endl;
    cout << "Bir islem seciniz" << endl;
    cout << "A: Kayit Arama" << endl;
    cout << "N: Numara ekle" << endl;
    cout << "E: Kayit Ekleme" << endl;
    cout << "G: Kayit Guncelleme" << endl;
    cout << "S: Kayit Silme" << endl;
    cout << "T: Hepsini Sil" << endl;
    cout << "C: Cikis" << endl;
    cout << endl;
    cout << "Bir secenek giriniz {A, E, G, S, T, C} : ";
}

bool islem_yap(char secim){
    bool sonlandir=false;
    switch (secim) {
        case 'A': case 'a':
            kayit_ara();
            break;
        case 'E': case 'e':
            kayit_ekle();
            break;
        case 'N': case 'n':
            numara_ekle();
            break;
        case 'G': case 'g':
            kayit_guncelle();
            break;
        case 'S': case 's':
            kayit_sil();
            break;
        case 'T': case 't':
            temizle();
            break;
        case 'C': case 'c':
            cout << "Programi sonlandirmak istediginize emin misiniz? (E/H):";
            cin >> secim;
            if(secim=='E' || secim=='e')
                sonlandir=true;
            break;
        default:
            cout << "Hata: Yanlis giris yaptiniz" << endl;
            cout << "Tekrar deneyiniz {A, E, G, S, C} :" ;
            cin >> secim;
            sonlandir = islem_yap(secim);
            break;
    }
    return sonlandir;
}

void kayit_ara(){
    char ad[AD_UZUNLUK];
    cout << "Lutfen aramak istediginiz kisinin adini giriniz (tum liste icin '*'a basiniz):" << endl;
    cin.ignore(1000, '\n');
    cin.getline(ad,AD_UZUNLUK);
    if(defter.ara(ad)==0){
        cout << "Aradiginiz kriterlere uygun kayit bulunamadi" << endl;
    }
    getchar();
}

void kayit_ekle(){
    Tel_Kayit yenikayit;
    cout << "Lutfen kaydetmek istediginiz kisinin bilgilerini giriniz" << endl;
    cout << "Ad : " ;
    cin.ignore(1000, '\n');
    cin.getline(yenikayit.ad,AD_UZUNLUK);
    defter.ekle(&yenikayit);
    cout << "Kaydiniz eklenmistir" << endl;
    getchar();
}
void numara_ekle(){
    list_node newnumber;
    Tel_Kayit yenikayit;
    char name[AD_UZUNLUK];
    cout<<"Please enter contact info you want to add"<<endl;
    cout<<"Name:";
    cin.ignore(1000,'\n');
    cin.getline(name,AD_UZUNLUK);
    if(defter.ara(name)==0){
        strcpy(yenikayit.ad,name);
        defter.ekle(&yenikayit);
    }
    else{
        cout<<"Phone number:";
        cin>>setw(TELNO_UZUNLUK)>>newnumber.telno;
        if(defter.addNumber(&newnumber,name)!=2){
            cout<<"Record added"<<endl;
        }
    }
    getchar();
}

void kayit_sil(){
    char ad[AD_UZUNLUK];
    char secim;
    cout << "Lutfen kaydini silmek istediginiz kisinin adini giriniz:" << endl;
    cin.ignore(1000, '\n');
    cin.getline(ad,AD_UZUNLUK);
    int kisisayisi=defter.ara(ad);
    if(kisisayisi==0){
        cout << "Aradiginiz kriterlere uygun kayit bulunamadi" << endl;
    }
    else {
        cout << "Kayit bulundu." << endl;
        cout << "Silmek istediginiz kayit bu mu? (e/h) " ;
        do{
            cin >> secim;
        }while (secim != 'e' && secim != 'h');
        if(secim == 'h') return;
        defter.sil(ad);
        cout << "Kayit silindi" <<endl;
    }
    getchar();
}

void kayit_guncelle(){
    char ad[AD_UZUNLUK];
    char secim;
    cout << "Lutfen kaydini guncellemek istediginiz kisinin adini giriniz (tum liste icin '*'a basiniz):" << endl;
    cin.ignore(1000, '\n');
    cin.getline(ad,AD_UZUNLUK);
    int kisisayisi=defter.ara(ad);
    if(kisisayisi==0){
        cout << "Aradiginiz kriterlere uygun kayit bulunamadi" << endl;
    }
    else {
        cout << "Kayit bulundu." << endl;
        cout << "Guncelleme yapacak misiniz? (e/h) ";
        do{
            cin >> secim;
        }while(secim != 'e' && secim != 'h');
        if(secim == 'h') return;
        Tel_Kayit yenikayit;
        cout << "Lutfen guncel bilgileri giriniz" << endl;
        cout << "Ad : " ;
        cin.ignore(1000, '\n');
        cin.getline(yenikayit.ad,AD_UZUNLUK);
        //cout << "Telefon numarasi :";
       // cin >> setw(TELNO_UZUNLUK) >> yenikayit.telno;
        defter.sil(ad);
        defter.ekle(&yenikayit);
        cout << "Kaydiniz basariyla guncellendi" <<endl;
    }
    getchar();
}

void temizle(){
    defter.agacbosalt(defter.kok);
}

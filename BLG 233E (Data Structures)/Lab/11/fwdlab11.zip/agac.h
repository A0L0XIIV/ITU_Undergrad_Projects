#ifndef AGAC_H
#define AGAC_H
#include "dugum.h"

struct Agac{
     Tel_dugum *kok;
    int dugumsayisi;
    char dosyaadi[20];
    FILE *teldefteri;
    void olustur();
    void kapat();
    void agacbosalt(Tel_dugum *);
    void ekle(Tel_dugum *);
    void sil(char *);
    int inorder_tara (Tel_dugum *);
    int ara(char *);
    list_node *head;
    int number;
    void create();
    int addNumber(list_node*,char*);
};

#endif
